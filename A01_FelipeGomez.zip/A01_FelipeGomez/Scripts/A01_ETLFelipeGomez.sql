--*************************************************************************--
-- Title: Assignment01
-- Author: RRoot
-- Desc: This file creates a Flush and Fill ETL process with SQL code
-- Change Log: When,Who,What
-- 2018-01-17,RRoot,Created File
-- TODO: 01/16/2024,Felipe Gomez,Updated code to include logging and transaction handling

-- Instructions: 
--  (STEP 1) Create the AdventureWorks_Basics database by running the provided code that restores the DB.
--  (STEP 2) Create a new Data Warehouse called DWAdventureWorks_Basics based on the AdventureWorks_Basics DB.
--           The DW should have three dimension tables (for Customers, Products, and Dates) and one fact table.
--  (STEP 3) Fill the DW by completing this ETL Script

-- HINT: Search for the TODO text in this script.
--**************************************************************************--
USE [DWAdventureWorks_Basics];
go
SET NoCount ON;


--********************************************************************--
-- Add Logging Support: Create Table, View and Stored Procedure
--********************************************************************--
If NOT Exists(Select * From Sys.tables where Name = 'ETLLog')
  Create -- Drop
  Table ETLLog
  (ETLLogID int identity Primary Key
  ,ETLDateAndTime datetime Default GetDate()
  ,ETLAction varchar(100)
  ,ETLLogMessage varchar(2000)
  );
go

Create or Alter View vETLLog
/* Desc: Formats ETL log data for better reporting
** Change Log: When,Who,What
** 20200117,RRoot,Created Sproc.
*/
As
  Select
   ETLLogID
  ,ETLDate = Format(ETLDateAndTime, 'D', 'en-us')
  ,ETLTime = Format(Cast(ETLDateAndTime as datetime2), 'HH:mm', 'en-us')
  ,ETLAction
  ,ETLLogMessage
  From ETLLog;
go

Create or Alter Procedure pInsETLLog
 (@ETLAction varchar(100), @ETLLogMessage varchar(2000))
/* Desc: This Sproc creates an admin table for logging ETL metadata. 
** Change Log: When,Who,What
** 2020-01-01,RRoot,Created Sproc
*/
As
Begin
  Declare @RC int = 0;
  Begin Try
    Begin Tran;
      Insert Into ETLLog
       (ETLAction,ETLLogMessage)
      Values
       (@ETLAction,@ETLLogMessage)
    Commit Tran;
    Set @RC = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback Tran;
    Set @RC = -1;
  End Catch
  Return @RC;
End
go -- If you don't put a go here the test code will be included in the Sproc body!

/* Testing Code:
 Declare @Status int;
 Exec @Status = pInsETLLog 'Test', 'Test message';
 Print @Status;
 Select * From vETLLog;
*/

--********************************************************************--
-- Pre-Load Tasks: Drop foreign key constraints and clear tables
--********************************************************************--
go
Create or Alter Procedure pETLDropForeignKeyConstraints
/* Desc: Removed FKs before truncation of the tables
** Change Log: When,Who,What
** 20200117,RRoot,Created Sproc.
*/
AS
 Begin
  Declare @RC int = 0;
  Begin Try

    -- ETL Processing Code --
    Alter Table [dbo].[FactSalesOrders] 
     Drop Constraint [FK_FactSalesOrders_DimCustomers] 

    Alter Table [dbo].[FactSalesOrders] 
     Drop Constraint [FK_FactSalesOrders_DimProducts]

    -- Optional: Unlike the other tables DimDates does not change often --
    Alter Table [dbo].[FactSalesOrders] 
     Drop Constraint [FK_FactSalesOrders_DimDates]

    Exec pInsETLLog
	        @ETLAction = 'pETLDropForeignKeyConstraints'
	       ,@ETLLogMessage = 'Foreign Keys dropped';
    Set @RC = +1
  End Try
  Begin Catch
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLDropForeignKeyConstraints'
	     ,@ETLLogMessage = 'Foreign Keys cannot be dropped (They may be missing or misnamed)';
    Set @RC = -1
  End Catch
  Return @RC;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLDropForeignKeyConstraints;
 Print @Status;
 Select * From vETLLog;
*/

go
Create or Alter Procedure pETLTruncateTables
/* Desc: Flushes all date from the tables
** Change Log: When,Who,What
** 20200117,RRoot,Created Sproc.
*/
AS
 Begin
  Declare @RC int = 0;
  Begin Try

    -- ETL Processing Code --
    Truncate Table [DWAdventureWorks_Basics].dbo.DimProducts;
    Truncate Table [DWAdventureWorks_Basics].dbo.DimCustomers;
    Truncate Table [DWAdventureWorks_Basics].dbo.FactSalesOrders;     
    -- Optional: Unlike the other tables DimDates does not change often --
    Truncate Table [DWAdventureWorks_Basics].dbo.DimDates; 

    Exec pInsETLLog
	        @ETLAction = 'pETLTruncateTables'
	       ,@ETLLogMessage = 'Tables data removed';
    Set @RC = +1
  End Try
  Begin Catch
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLTruncateTables'
	     ,@ETLLogMessage = @ErrorMessage;
    Set @RC = -1
  End Catch
  Return @RC;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLTruncateTables;
 Print @Status;
 Select * From vETLLog;
*/
go

--********************************************************************--
-- B) FILL the Tables
--********************************************************************--

/****** [dbo].[DimDates] ******/
Create or Alter Procedure pETLFillDimDates
/* Desc: Inserts data Into DimDates
** Change Log: When,Who,What
** 20200117,RRoot,Created Sproc.
*/
AS
 Begin
  Declare @RC int = 0;
  Begin Try

    -- ETL Processing Code --
      Declare @StartDate datetime = '01/01/2000'
      Declare @EndDate datetime = '12/31/2010' 
      Declare @DateInProcess datetime  = @StartDate
      -- Loop through the dates until you reach the end date
       Begin Tran
      While @DateInProcess <= @EndDate
       Begin
       -- Add a row Into the date dimension table for this date
       Insert Into DimDates 
       ( [DateKey], [FullDate],[FullDateName],[MonthID],[MonthName],[YearID],[YearName])
       Values ( 
         Cast(Convert(nVarchar(50), @DateInProcess, 112) as int) -- [DateKey]
        ,@DateInProcess -- [FullDate]
        ,DateName(weekday, @DateInProcess) + ', ' + Convert(nVarchar(50), @DateInProcess, 110) -- [DateName]  
        ,Cast(Left(Convert(nVarchar(50), @DateInProcess, 112), 6) as int)  -- [MonthID]
        ,DateName(month, @DateInProcess) + ' - ' + DateName(YYYY,@DateInProcess) -- [MonthName]
        ,Year(@DateInProcess) -- [YearID] 
        ,Cast(Year(@DateInProcess ) as nVarchar(50)) -- [YearName] 
        )  
       -- Add a day and loop again
       Set @DateInProcess = DateAdd(d, 1, @DateInProcess)
       End
	   Commit Tran

    Exec pInsETLLog
	        @ETLAction = 'pETLFillDimDates'
	       ,@ETLLogMessage = 'DimDates filled';
    Set @RC = +1
  End Try
  Begin Catch
     If @@TRANCOUNT > 0 Rollback Tran;
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLFillDimDates'
	     ,@ETLLogMessage = @ErrorMessage;
    Set @RC = -1
  End Catch
  Return @RC;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLFillDimDates;
 Print @Status;
 Select * From DimDates;
 Select * From vETLLog;
*/
go


/****** [dbo].[DimProducts] ******/
go 
Create or Alter View vETLDimProducts
/* Desc: Extracts and transforms data for DimProducts
** Change Log: When,Who,What
** 20200117,RRoot,Created Sproc.
*/
As
  Select
    [ProductID] = p.ProductID
   ,[ProductName] = CAST(p.Name as nVarchar(50))
   ,[StandardListPrice] = Cast(p.ListPrice as decimal(18,4))
   ,[ProductSubCategoryID] = IsNull(ps.ProductSubcategoryID, -1)
   ,[ProductSubCategoryName] = CAST(ps.Name as nVarchar(50))
   ,[ProductCategoryID] = IsNull(pc.ProductCategoryID, -1)
   ,[ProductCategoryName] = CAST(pc.Name as nVarchar(50))
  From [AdventureWorks_Basics].dbo.ProductCategory as pc
  Inner Join [AdventureWorks_Basics].dbo.ProductSubcategory as ps
   On pc.ProductCategoryID = ps.ProductCategoryID
  Inner Join [AdventureWorks_Basics].dbo.Products as p
  ON ps.ProductSubcategoryID = p.ProductSubcategoryID;
go
/* Testing Code:
 Select * From vETLDimProducts;
*/

go
Create or Alter Procedure pETLFillDimProducts
/* Desc: Inserts data Into DimProducts using the vETLDimProducts view
** Change Log: When,Who,What
** 20200117,RRoot,Created Sproc.
*/
AS
 Begin
  Declare @RC int = 0;
  Begin Try

    -- ETL Processing Code --
    If ((Select Count(*) From DimProducts) = 0)
     Begin Tran
      Insert Into [DWAdventureWorks_Basics].dbo.DimProducts
      ([ProductID]
      ,[ProductName]
      ,[StandardListPrice]
      ,[ProductSubCategoryID]
      ,[ProductSubCategoryName]
      ,[ProductCategoryID]
      ,[ProductCategoryName]
      )
      Select
        [ProductID]
       ,[ProductName]
       ,[StandardListPrice]
       ,[ProductSubCategoryID]
       ,[ProductSubCategoryName]
       ,[ProductCategoryID]
       ,[ProductCategoryName]
      FROM vETLDimProducts
    Commit Tran

    Exec pInsETLLog
	        @ETLAction = 'pETLFillDimProducts'
	       ,@ETLLogMessage = 'DimProducts filled';
    Set @RC = +1
  End Try
  Begin Catch
     If @@TRANCOUNT > 0 Rollback Tran;
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLFillDimProducts'
	     ,@ETLLogMessage = @ErrorMessage;
    Set @RC = -1
  End Catch
  Return @RC;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLFillDimProducts;
 Print @Status;
 Select * From DimProducts;
 Select * From vETLLog;
*/


/****** [dbo].[DimCustomers] ******/
--print 'TODO: Add code for DimCustomers'
go 
Create or Alter View vETLDimCustomers
/* Desc: Extracts and transforms data for DimCustomers
** Change Log: When,Who,What
** 20230116,FGomez,Created Sproc.
*/
As
  Select
    [CustomerId] = c.CustomerID
   ,[CustomerFullName] = CAST(CONCAT(c.FirstName, ' ', c.LastName) AS nvarchar(100))
   ,[CustomerCityName] = CAST(c.City AS nvarchar(50))
   ,[CustomerStateProvinceName] = CAST(c.StateProvinceName AS nvarchar(50))
   ,[CustomerCountryRegionCode] = CAST(c.CountryRegionCode AS nvarchar(50))
   ,[CustomerCountryRegionName] = CAST(c.CountryRegionName AS nvarchar(50))
  From [AdventureWorks_Basics].dbo.Customer as c
go
/* Testing Code:
 Select * From vETLDimCustomers;
*/

go
Create or Alter Procedure pETLFillDimCustomers
/* Desc: Inserts data Into DimCustomers using the vETLDimCustomers view
** Change Log: When,Who,What
** 20230116,FGomez,Created Sproc.
*/
AS
 Begin
  Declare @RC int = 0;
  Begin Try

    -- ETL Processing Code --
    If ((Select Count(*) From DimCustomers) = 0)
     Begin Tran
      Insert Into [DWAdventureWorks_Basics].dbo.DimCustomers
      ([CustomerId]
      ,[CustomerFullName]
      ,[CustomerCityName]
      ,[CustomerStateProvinceName]
      ,[CustomerCountryRegionCode]
      ,[CustomerCountryRegionName]
      )
      Select
        [CustomerId]
       ,[CustomerFullName]
       ,[CustomerCityName]
       ,[CustomerStateProvinceName]
       ,[CustomerCountryRegionCode]
       ,[CustomerCountryRegionName]
      FROM vETLDimCustomers
    Commit Tran

    Exec pInsETLLog
	        @ETLAction = 'pETLFillDimCustomers'
	       ,@ETLLogMessage = 'DimCustomers filled';
    Set @RC = +1
  End Try
  Begin Catch
     If @@TRANCOUNT > 0 Rollback Tran;
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLFillDimCustomers'
	     ,@ETLLogMessage = @ErrorMessage;
    Set @RC = -1
  End Catch
  Return @RC;
 End
go

/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLFillDimCustomers;
 Print @Status;
 Select * From DimCustomers;
 Select * From vETLLog;
*/
go

/****** [dbo].[FactSalesOrders] ******/
--print 'TODO: Add code for FactSalesOrders'
go 
Create or Alter View vETLFactSalesOrders
/* Desc: Extracts and transforms data for FactSalesOrders
** Change Log: When,Who,What
** 20230116,FGomez,Created Sproc.
*/
As
  Select
    [SalesOrderID] = soh.SalesOrderID
   ,[SalesOrderDetailID] = sod.SalesOrderDetailID
   ,[OrderDateKey] = dd.DateKey
   ,[CustomerKey] = dc.CustomerKey
   ,[ProductKey] = dp.ProductKey
   ,[OrderQty] = sod.OrderQty
   ,[ActualUnitPrice] = sod.UnitPrice
  From [AdventureWorks_Basics].dbo.SalesOrderHeader as soh
  INNER JOIN [AdventureWorks_Basics].dbo.SalesOrderDetail as sod
   ON soh.SalesOrderID = sod.SalesOrderID
  INNER JOIN [DWAdventureWorks_Basics].dbo.DimDates dd
   ON CAST(soh.OrderDate AS date) = CAST(dd.FullDate AS date)
  INNER JOIN [DWAdventureWorks_Basics].dbo.DimCustomers as dc
   ON soh.CustomerID = dc.CustomerID
  INNER JOIN [DWAdventureWorks_Basics].dbo.DimProducts as dp
   ON sod.ProductID = dp.ProductID


go
/* Testing Code:
 Select * From vETLFactSalesOrders;
*/

go
Create or Alter Procedure pETLFillFactSalesOrders
/* Desc: Inserts data Into FactSalesOrders using the vETLFactSalesOrders view
** Change Log: When,Who,What
** 20230116,FGomez,Created Sproc.
*/
AS
 Begin
  Declare @RC int = 0;
  Begin Try

    -- ETL Processing Code --
    If ((Select Count(*) From FactSalesOrders) = 0)
     Begin Tran
      Insert Into [DWAdventureWorks_Basics].dbo.FactSalesOrders
      ([SalesOrderID]
      ,[SalesOrderDetailID]
      ,[OrderDateKey]
      ,[CustomerKey]
      ,[ProductKey]
      ,[OrderQty]
	  ,[ActualUnitPrice]
      )
      Select
        [SalesOrderID]
       ,[SalesOrderDetailID]
       ,[OrderDateKey]
       ,[CustomerKey]
       ,[ProductKey]
       ,[OrderQty]
	   ,[ActualUnitPrice]
      FROM vETLFactSalesOrders
    Commit Tran

    Exec pInsETLLog
	        @ETLAction = 'pETLFillFactSalesOrders'
	       ,@ETLLogMessage = 'FactSalesOrders filled';
    Set @RC = +1
  End Try
  Begin Catch
     If @@TRANCOUNT > 0 Rollback Tran;
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLFillFactSalesOrders'
	     ,@ETLLogMessage = @ErrorMessage;
    Set @RC = -1
  End Catch
  Return @RC;
 End
go

/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLFillFactSalesOrders;
 Print @Status;
 Select * From FactSalesOrders;
 Select * From vETLLog;
*/
go

--********************************************************************--
-- C) Re-Create the FOREIGN KEY CONSTRAINTS
--********************************************************************--
/****** [dbo].[FactOrders] ******/
--print 'TODO: Add code to recreate Foreign Keys'
go
Go
Create or Alter Procedure pETLAddForeignKeyConstraints
/* Desc: This Sproc Replaces the Foreign Keys Constraints.
** Change Log: When,Who,What
** 20230116,FGomez,Created Sproc.
*/
AS
Begin 
	Declare @RC int = 1;
	Declare @Message varchar(1000);
  Begin Try
	Alter Table FactSalesOrders Add Constraint FK_FactSalesOrders_DimDates
	  Foreign Key(OrderDateKey) References DimDates(DateKey);
	Alter Table FactSalesOrders Add Constraint FK_FactSalesOrders_DimCustomers
	  Foreign Key([CustomerKey]) References DimCustomers(CustomerKey);
	Alter Table FactSalesOrders Add Constraint FK_FactSalesOrders_DimProducts
	  Foreign Key([ProductKey]) References DimProducts(ProductKey);
	Set @Message = 'Foreign Keys replaced on all tables';
	Exec pInsEtlLog
 	       @ETLAction = 'pETLAddForeignKeyConstraints'
 	      ,@ETLLogMessage = @Message;
    Set @RC = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback;
    Declare @ErrorMessage nvarchar(1000) = Error_Message();
    Exec pInsEtlLog 
         @ETLAction = 'pEtlReplaceFKs'
        ,@ETLLogMessage = @ErrorMessage;
    Set @RC = -1;
  End Catch
  Return @RC;
End
Go


/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLAddForeignKeyConstraints;
 Print @Status;
 Select * From vETLLog;
*/
go

--********************************************************************--
-- D) Review the results of this script
--********************************************************************--
go
Declare @Status int;
Exec @Status = pETLDropForeignKeyConstraints;
Select [Object] = 'pETLDropForeignKeyConstraints', [Status] = @Status;

Exec @Status = pETLTruncateTables;
Select [Object] = 'pETLTruncateTables', [Status] = @Status;

Exec @Status = pETLFillDimDates;
Select [Object] = 'pETLFillDimDates', [Status] = @Status;

Exec @Status = pETLFillDimProducts;
Select [Object] = 'pETLFillDimProducts', [Status] = @Status;

Exec @Status = pETLFillDimCustomers;
Select [Object] = 'pETLFillDimCustomers', [Status] = @Status;

Exec @Status = pETLFillFactSalesOrders;
Select [Object] = 'pETLFillFactOrders', [Status] = @Status;

Exec @Status = pETLAddForeignKeyConstraints;
Select [Object] = 'pETLAddForeignKeyConstraints', [Status] = @Status;

go
Select [DimDates] = Count(*) From [dbo].[DimDates];
Select [DimProducts] = Count(*) From [dbo].[DimProducts];
Select [DimCustomers] = Count(*) From [dbo].[DimCustomers];
Select [FactSalesOrders] = Count(*) From [dbo].[FactSalesOrders];
Select * From vETLLog;
-- Delete From ETLLog;