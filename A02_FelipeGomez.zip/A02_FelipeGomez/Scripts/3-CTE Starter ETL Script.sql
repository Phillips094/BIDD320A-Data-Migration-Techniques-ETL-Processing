--*************************************************************************--
-- Title: Assignment02
-- Author: FGomez
-- Desc: This file tests you knowlege on how to create a Incremental ETL process with SQL code
-- Change Log: When,Who,What
-- 2021-01-17,RRoot,Created File
-- 2024-01-22,FGomez,Completed File

-- Instructions: 
-- (STEP 1) Restore the AdventureWorks_Basics database by running the provided code.
-- (STEP 2) Create a new Data Warehouse called DWAdventureWorks_BasicsWithSCD based on the AdventureWorks_Basics DB.
--          The DW should have three dimension tables (for Customers, Products, and Dates) and one fact table.
-- (STEP 3) Fill the DW by creating an Incremental ETL Script
--**************************************************************************--
USE [DWAdventureWorks_BasicsWithSCD];
go
SET NoCount ON;
go

--  Setup Logging Objects ----------------------------------------------------

If NOT Exists(Select * From Sys.tables where Name = 'ETLLog')
  Create -- Drop
  Table ETLLog
  (ETLLogID int identity Primary Key
  ,ETLDateAndTime datetime Default GetDate()
  ,ETLAction varchar(100)
  ,ETLLogMessage varchar(2000)
  );
go

Create or Alter View vETLLog
As
  Select
   ETLLogID
  ,ETLDate = Format(ETLDateAndTime, 'D', 'en-us')
  ,ETLTime = Format(Cast(ETLDateAndTime as datetime2), 'HH:mm', 'en-us')
  ,ETLAction
  ,ETLLogMessage
  From ETLLog;
go


Create or Alter Proc pInsETLLog
 (@ETLAction varchar(100), @ETLLogMessage varchar(2000))
--*************************************************************************--
-- Desc:This Sproc creates an admin table for logging ETL metadata. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
As
Begin
  Declare @ReturnCode int = 0;
  Begin Try
    Begin Tran;
      Insert Into ETLLog
       (ETLAction,ETLLogMessage)
      Values
       (@ETLAction,@ETLLogMessage)
    Commit Tran;
    Set @ReturnCode = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback Tran;
    Set @ReturnCode = -1;
  End Catch
  Return @ReturnCode;
End
Go

--********************************************************************--
-- A) Drop the FOREIGN KEY CONSTRAINTS and Clear the tables
 -- NOT NEEDED FOR INCREMENTAL LOADING: 
--********************************************************************--


--********************************************************************--
-- B) Synchronize the Tables
--********************************************************************--

/****** [dbo].[DimDates] ******/
Create or Alter Procedure pETLFillDimDates
/* Author: RRoot
** Desc: Inserts data Into DimDates
** Change Log: When,Who,What
** 20200117,RRoot,Created Sproc.
*/
AS
 Begin
  Declare @ReturnCode int = 0;
  Begin Try

    -- ETL Processing Code --
	IF ((Select COUNT(*) FROM DimDates) = 0) --NEEDED TO ADD THIS TO STOP GETTING @STATUS = -1. 
	Begin
      Declare @StartDate datetime = '01/01/2000'
      Declare @EndDate datetime = '12/31/2025' 
      Declare @DateInProcess datetime  = @StartDate
      -- Loop through the dates until you reach the end date
      While @DateInProcess <= @EndDate
       Begin
       -- Add a row Into the date dimension table for this date
       Begin Tran;
       Insert Into DimDates 
       ( [DateKey], [FullDate],[FullDateName],[MonthID],[MonthName],[YearID],[YearName])
       Values ( 
         Cast(Convert(nVarchar(50), @DateInProcess, 112) as int) -- [DateKey]
        ,@DateInProcess -- [FullDate]
        ,DateName(weekday, @DateInProcess) + ', ' + Convert(nVarchar(50), @DateInProcess, 110) -- [DateName]  
        ,Cast(Left(Convert(nVarchar(50), @DateInProcess, 112), 6) as int)  -- [MonthID]
        ,DateName(month, @DateInProcess) + ' - ' + DateName(YYYY,@DateInProcess) -- [MonthName]
        ,Year(@DateInProcess) -- [YearID] 
        ,Cast(Year(@DateInProcess ) as nVarchar(50)) -- [YearName] 
        )  
       -- Add a day and loop again
       Set @DateInProcess = DateAdd(d, 1, @DateInProcess)
       Commit Tran;
       End
	End
    Exec pInsETLLog
	        @ETLAction = 'pETLFillDimDates'
	       ,@ETLLogMessage = 'DimDates filled';
    Set @ReturnCode = +1
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback Tran;
    Declare @ErrorMessage nvarchar(1000) = Error_Message();
	  Exec pInsETLLog 
	     @ETLAction = 'pETLFillDimDates'
	    ,@ETLLogMessage = @ErrorMessage;
    Set @ReturnCode = -1;
  End Catch
  Return @ReturnCode;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLFillDimDates;
 Print @Status;
 Select * From DimDates;
 Select * From vETLLog;
*/
go


/****** [dbo].[DimProducts] ******/
go 
Create or Alter View vETLDimProducts
/* Author: FGomez
** Desc: Extracts and transforms data for DimProducts
** Change Log: When,Who,What
** 2024-01-22,FGomez,Created Sproc.
*/
As
  SELECT [ProductID] = p.ProductID
        ,[ProductName] = CAST(p.Name as nVarchar(50))
	    ,[StandardListPrice] = Cast(p.ListPrice as decimal(18,4))
		,[ProductSubCategoryID] = p.ProductSubcategoryID
		,[ProductSubCategoryName] = CAST(ps.Name as nVarchar(50))
		,[ProductCategoryID] = ps.ProductCategoryID
		,[ProductCategoryName] = CAST(pc.Name as nVarchar(50))
		,[IsCurrent] = 1
  FROM [AdventureWorks_Basics].dbo.Products AS p
  INNER JOIN [AdventureWorks_Basics].dbo.ProductSubcategory AS ps
   ON p.ProductSubCategoryID = ps.ProductSubcategoryID
  INNER JOIN [AdventureWorks_Basics].dbo.ProductCategory AS pc
   ON ps.ProductCategoryID = pc.ProductCategoryID;
go
/* Testing Code:
 Select * From vETLDimProducts;
 SELECT * FROM DimProducts;
*/

go
Create or Alter Procedure pETLSyncDimProducts
/* Author: FGomez
** Desc: Updates data in DimProducts using the vETLDimProducts view
** Change Log: When,Who,What
** 2024-01-22,FGomez,Created Sproc.
*/
AS
 Begin
  Declare @ReturnCode int = 0;
  Begin Try
    -- ETL Processing Code --
	    --FOR UPDATES
		WITH ChangedProducts AS(
		     SELECT ProductID, ProductName, StandardListPrice, ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID, ProductCategoryName FROM vETLDimProducts
			 EXCEPT
			 SELECT ProductID, ProductName, StandardListPrice, ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID, ProductCategoryName FROM DimProducts
			 WHERE IsCurrent = 1)
	    UPDATE [DWAdventureWorks_BasicsWithSCD].dbo.DimProducts
		 SET EndDate = CONVERT(DATE, GETDATE())
			,IsCurrent = 0
		 WHERE ProductID IN (SELECT ProductID FROM ChangedProducts);
		--FOR INSERTS
	    WITH AddedORChangedProducts
	    AS(
		     SELECT ProductID, ProductName, StandardListPrice, ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID, ProductCategoryName FROM vETLDimProducts
			 EXCEPT
			 SELECT ProductID, ProductName, StandardListPrice, ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID, ProductCategoryName FROM DimProducts
			 WHERE IsCurrent = 1)
	    INSERT INTO [DWAdventureWorks_BasicsWithSCD].dbo.DimProducts
		([ProductID], [ProductName], [StandardListPrice], [ProductSubCategoryID], [ProductSubCategoryName], [ProductCategoryID], [ProductCategoryName], [StartDate], [EndDate], [IsCurrent])
		SELECT
		  [ProductID]
		 ,[ProductName]
		 ,[StandardListPrice]
		 ,[ProductSubCategoryID]
		 ,[ProductSubCategoryName]
		 ,[ProductCategoryID]
		 ,[ProductCategoryName]
		 ,[StartDate] = CONVERT(DATE, GETDATE())
		 ,[EndDate] = NULL
		 ,[IsCurrent] = 1
		FROM vETLDimProducts
		WHERE ProductID IN (SELECT ProductID FROM AddedORChangedProducts);
	    --FOR DELETES
		WITH DeletedProducts AS(
		     SELECT ProductID, ProductName, StandardListPrice, ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID, ProductCategoryName FROM DimProducts
			 WHERE IsCurrent = 1
			 EXCEPT
			 SELECT ProductID, ProductName, StandardListPrice, ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID, ProductCategoryName FROM vETLDimProducts)
	    UPDATE [DWAdventureWorks_BasicsWithSCD].dbo.DimProducts
			SET EndDate = CONVERT(DATE, GETDATE())
			   ,IsCurrent = 0
			WHERE ProductID IN (SELECT ProductID FROM DeletedProducts);
    -- ETL Logging Code --
    Exec pInsETLLog
	        @ETLAction = 'pETLSyncDimProducts'
	       ,@ETLLogMessage = 'DimProducts synced';
    Set @ReturnCode = +1
  End Try
  Begin Catch
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLSyncDimProducts'
	     ,@ETLLogMessage = @ErrorMessage;
    Set @ReturnCode = -1
  End Catch
  Return @ReturnCode;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLSyncDimProducts;
 Print @Status;
 Select * From DimProducts Order By ProductID
*/


/****** [dbo].[DimCustomers] ******/
go 
Create or Alter View vETLDimCustomers
/* Author: FGomez
** Desc: Extracts and transforms data for DimCustomers
** Change Log: When,Who,What
** 2024-01-22,FGomez,Created Sproc.
*/
As
  SELECT [CustomerId] = c.CustomerID
		,[CustomerFullName] = CAST(CONCAT(c.FirstName, ' ', c.LastName) AS nvarchar(100))
		,[CustomerCityName] = CAST(c.City AS nvarchar(50))
		,[CustomerStateProvinceName] = CAST(c.StateProvinceName AS nvarchar(50))
		,[CustomerCountryRegionCode] = CAST(c.CountryRegionCode AS nvarchar(50))
		,[CustomerCountryRegionName] = CAST(c.CountryRegionName AS nvarchar(50))
		,[IsCurrent] = 1
  FROM [AdventureWorks_Basics].dbo.Customer as c
go
/* Testing Code:
 Select * From vETLDimCustomers;
 Select * From DimCustomers;
*/

go
Create or Alter Procedure pETLSyncDimCustomers
/* Author: FGomez
** Desc: Inserts data into DimCustomers
** Change Log: When,Who,What
** 2024-01-22,FGomez,Created Sproc.
*/
As
 Begin
  Declare @ReturnCode int = 0;
  Begin Try
    -- ETL Processing Code --
	    --FOR UPDATES
		WITH ChangedCustomers AS(
		     SELECT CustomerId, CustomerFullName, CustomerCityName, CustomerStateProvinceName, CustomerCountryRegionCode, CustomerCountryRegionName FROM vETLDimCustomers
			 EXCEPT
			 SELECT CustomerId, CustomerFullName, CustomerCityName, CustomerStateProvinceName, CustomerCountryRegionCode, CustomerCountryRegionName FROM DimCustomers
			 WHERE IsCurrent = 1)
	    UPDATE [DWAdventureWorks_BasicsWithSCD].dbo.DimCustomers
		 SET EndDate = CONVERT(DATE, GETDATE())
			,IsCurrent = 0
		 WHERE CustomerId IN (SELECT CustomerId FROM ChangedCustomers);
		--FOR INSERTS
	    WITH AddedORChangedCustomers
	    AS(
		     SELECT CustomerId, CustomerFullName, CustomerCityName, CustomerStateProvinceName, CustomerCountryRegionCode, CustomerCountryRegionName FROM vETLDimCustomers
			 EXCEPT
			 SELECT CustomerId, CustomerFullName, CustomerCityName, CustomerStateProvinceName, CustomerCountryRegionCode, CustomerCountryRegionName FROM DimCustomers
			 WHERE IsCurrent = 1)
	    INSERT INTO [DWAdventureWorks_BasicsWithSCD].dbo.DimCustomers
		([CustomerId], [CustomerFullName], [CustomerCityName], [CustomerStateProvinceName], [CustomerCountryRegionCode], [CustomerCountryRegionName], [StartDate], [EndDate], [IsCurrent])
		SELECT
		  [CustomerId]
		 ,[CustomerFullName]
		 ,[CustomerCityName]
		 ,[CustomerStateProvinceName]
		 ,[CustomerCountryRegionCode]
		 ,[CustomerCountryRegionName]
		 ,[StartDate] = CONVERT(DATE, GETDATE())
		 ,[EndDate] = NULL
		 ,[IsCurrent] = 1
		FROM vETLDimCustomers
		WHERE CustomerId IN (SELECT CustomerId FROM AddedORChangedCustomers);
	    --FOR DELETES
		WITH DeletedCustomers AS(
		     SELECT CustomerId, CustomerFullName, CustomerCityName, CustomerStateProvinceName, CustomerCountryRegionCode, CustomerCountryRegionName FROM DimCustomers
			 WHERE IsCurrent = 1
			 EXCEPT
			 SELECT CustomerId, CustomerFullName, CustomerCityName, CustomerStateProvinceName, CustomerCountryRegionCode, CustomerCountryRegionName FROM vETLDimCustomers)
	    UPDATE [DWAdventureWorks_BasicsWithSCD].dbo.DimCustomers
			SET EndDate = CONVERT(DATE, GETDATE())
			   ,IsCurrent = 0
			WHERE CustomerId IN (SELECT CustomerId FROM DeletedCustomers);
    -- ETL Logging Code --
    Exec pInsETLLog
	        @ETLAction = 'pETLSyncDimCustomers'
	       ,@ETLLogMessage = 'DimCustomers synced';
    Set @ReturnCode = +1
  End Try
  Begin Catch
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLSyncDimCustomers'
	     ,@ETLLogMessage = @ErrorMessage;
    Set @ReturnCode = -1
  End Catch
  Return @ReturnCode;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLSyncDimCustomers;
 Print @Status;
 Select * From DimCustomers Order By CustomerID
*/
go


/****** [dbo].[FactOrders] ******/
go 
Create or Alter View vETLFactOrders
/* Author: FGomez
** Desc: Extracts and transforms data for FactSalesOrders
** Change Log: When,Who,What
** 2024-01-22,FGomez,Created Sproc.
*/
As
  SELECT [SalesOrderID] = soh.SalesOrderID
		,[SalesOrderDetailID] = sod.SalesOrderDetailID
		,[OrderDate]
		,[OrderDateKey] = CAST(CONVERT(NVARCHAR(50), OrderDate, 112) AS INT)
		,soh.[CustomerId]
		,[CustomerKey] = dc.CustomerKey
		,sod.[ProductID]
		,[ProductKey] = dp.ProductKey
		,[OrderQty] = sod.OrderQty
		,[ActualUnitPrice] = sod.UnitPrice
  FROM [AdventureWorks_Basics].dbo.SalesOrderHeader as soh
  INNER JOIN [AdventureWorks_Basics].dbo.SalesOrderDetail as sod
   ON soh.SalesOrderID = sod.SalesOrderID
  INNER JOIN [DWAdventureWorks_BasicsWithSCD].dbo.DimCustomers as dc
   ON soh.CustomerID = dc.CustomerID
  INNER JOIN [DWAdventureWorks_BasicsWithSCD].dbo.DimProducts as dp
   ON sod.ProductID = dp.ProductID
  WHERE dc.IsCurrent = 1 AND dp.IsCurrent = 1
go
/* Testing Code:
 Select * From vETLDimCustomers;
*/

go
Create or Alter Procedure pETLSyncFactOrders
/* Author: FGomez
** Desc: Inserts data into FactOrders
** Change Log: When,Who,What
** 2024-01-22,FGomez,Created Sproc.
*/
As
 Begin
  Declare @ReturnCode int = 0;
  Begin Try
    -- ETL Processing Code --
	Begin Tran;
	  Merge Into FactSalesOrders as t
       Using vETLFactOrders as s -- For Merge to work with SCD tables, I need to insert a new row when the following is not true:
        On  t.SalesOrderID = s.SalesOrderID
        And t.SalesOrderDetailID = s.SalesOrderDetailID
		--And t.OrderDateKey = s.OrderDateKey
		And t.CustomerKey = s.CustomerKey
		And t.ProductKey = s.ProductKey
        --And t.OrderQty = s.OrderQty
        --And t.ActualUnitPrice = s.ActualUnitPrice -- Added to capture row where all but this is a match. This when all is the same, the the is current status then       
       When Not Matched -- At least one column value does not match add a new row:
        Then
         Insert (SalesOrderID, SalesOrderDetailID, OrderDateKey, CustomerKey, ProductKey, OrderQty, ActualUnitPrice)
          Values (s.SalesOrderID
                 ,s.SalesOrderDetailID
				 ,s.OrderDateKey
				 ,s.CustomerKey
				 ,s.ProductKey
                 ,s.OrderQty
                 ,s.ActualUnitPrice)
	    When Matched
		 AND (s.OrderQty <> t.OrderQty
		 OR   s.ActualUnitPrice <> t.ActualUnitPrice
		 OR   s.OrderDateKey <> t.OrderDatekey
		  )
		 Then UPDATE
			   SET t.OrderQty = s.OrderQty
			      ,t.ActualUnitPrice = s.ActualUnitPrice
				  ,t.OrderDateKey = s.OrderDateKey
        When Not Matched By Source -- If there is a row in the target (fact) table that is no longer in the source table
         Then -- indicate that row is no longer current
          DELETE;
	Commit Tran;
	Set @ReturnCode = +1
    Exec pInsETLLog
	        @ETLAction = 'pETLSyncFactOrders'
	       ,@ETLLogMessage = 'FactSales Synced';
    Set @ReturnCode = 1;
   End try
   Begin catch
	 IF @@TranCount > 0 Rollback Tran;
     Declare @ErrorMessage nvarchar(1000) = Error_Message()
	 Exec pInsETLLog 
	      @ETLAction = 'pETLSyncFactOrders'
	     ,@ETLLogMessage = @ErrorMessage;
     Set @ReturnCode = -1;
   End Catch
   Return @ReturnCode;
 End
;
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLSyncFactOrders;
 Print @Status;
*/
go

--********************************************************************--
-- C)  NOT NEEDED FOR INCREMENTAL LOADING: Re-Create the FOREIGN KEY CONSTRAINTS
--********************************************************************--


--********************************************************************--
-- D) Review the results of this script
--********************************************************************--
go
Declare @Status int = 0;
Exec @Status = pETLSyncDimProducts;
Select [Object] = 'pETLSyncDimProducts', [Status] = @Status;

Exec @Status = pETLSyncDimCustomers;
Select [Object] = 'pETLSyncDimCustomers', [Status] = @Status;

Exec @Status = pETLFillDimDates;
Select [Object] = 'pETLFillDimDates', [Status] = @Status;

Exec @Status = pETLSyncFactOrders;
Select [Object] = 'pETLFillFactOrders', [Status] = @Status;

go
Select * from [dbo].[DimProducts];
Select * from [dbo].[DimCustomers];
Select * from [dbo].[DimDates];
Select * from [dbo].[FactSalesOrders] ORDER BY 1;