--*************************************************************************--
-- Title: Assignment02
-- Author: <YourNameHere>
-- Desc: This file tests you knowlege on how to create a Incremental ETL process with SQL code
-- Change Log: When,Who,What
-- 2021-01-17,RRoot,Created File
-- <date>,<your name here>,Completed File

-- Instructions: 
-- (STEP 1) Restore the AdventureWorks_Basics database by running the provided code.
-- (STEP 2) Create a new Data Warehouse called DWAdventureWorks_BasicsWithSCD based on the AdventureWorks_Basics DB.
--          The DW should have three dimension tables (for Customers, Products, and Dates) and one fact table.
-- (STEP 3) Fill the DW by creating an Incremental ETL Script
--**************************************************************************--
USE [DWAdventureWorks_BasicsWithSCD];
go
SET NoCount ON;

--  Setup Logging Objects ----------------------------------------------------

If NOT Exists(Select * From Sys.tables where Name = 'ETLLog')
  Create -- Drop
  Table ETLLog
  (ETLLogID int identity Primary Key
  ,ETLDateAndTime datetime Default GetDate()
  ,ETLAction varchar(100)
  ,ETLLogMessage varchar(2000)
  );
go

Create or Alter View vETLLog
As
  Select
   ETLLogID
  ,ETLDate = Format(ETLDateAndTime, 'D', 'en-us')
  ,ETLTime = Format(Cast(ETLDateAndTime as datetime2), 'HH:mm', 'en-us')
  ,ETLAction
  ,ETLLogMessage
  From ETLLog;
go


Create or Alter Proc pInsETLLog
 (@ETLAction varchar(100), @ETLLogMessage varchar(2000))
--*************************************************************************--
-- Desc:This Sproc creates an admin table for logging ETL metadata. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
As
Begin
  Declare @ReturnCode int = 0;
  Begin Try
    Begin Tran;
      Insert Into ETLLog
       (ETLAction,ETLLogMessage)
      Values
       (@ETLAction,@ETLLogMessage)
    Commit Tran;
    Set @ReturnCode = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback Tran;
    Set @ReturnCode = -1;
  End Catch
  Return @ReturnCode;
End
Go

--********************************************************************--
-- A) Drop the FOREIGN KEY CONSTRAINTS and Clear the tables
 -- NOT NEEDED FOR INCREMENTAL LOADING: 
--********************************************************************--


--********************************************************************--
-- B) Synchronize the Tables
--********************************************************************--

/****** [dbo].[DimDates] ******/
Create or Alter Procedure pETLFillDimDates
/* Author: RRoot
** Desc: Inserts data Into DimDates
** Change Log: When,Who,What
** 20200117,RRoot,Created Sproc.
*/
AS
 Begin
  Declare @ReturnCode int = 0;
  Begin Try

    -- ETL Processing Code --
      Declare @StartDate datetime = '01/01/2000'
      Declare @EndDate datetime = '12/31/2010' 
      Declare @DateInProcess datetime  = @StartDate
      -- Loop through the dates until you reach the end date
      While @DateInProcess <= @EndDate
       Begin
       -- Add a row Into the date dimension table for this date
       Begin Tran;
       Insert Into DimDates 
       ( [DateKey], [FullDate],[FullDateName],[MonthID],[MonthName],[YearID],[YearName])
       Values ( 
         Cast(Convert(nVarchar(50), @DateInProcess, 112) as int) -- [DateKey]
        ,@DateInProcess -- [FullDate]
        ,DateName(weekday, @DateInProcess) + ', ' + Convert(nVarchar(50), @DateInProcess, 110) -- [DateName]  
        ,Cast(Left(Convert(nVarchar(50), @DateInProcess, 112), 6) as int)  -- [MonthID]
        ,DateName(month, @DateInProcess) + ' - ' + DateName(YYYY,@DateInProcess) -- [MonthName]
        ,Year(@DateInProcess) -- [YearID] 
        ,Cast(Year(@DateInProcess ) as nVarchar(50)) -- [YearName] 
        )  
       -- Add a day and loop again
       Set @DateInProcess = DateAdd(d, 1, @DateInProcess)
       Commit Tran;
       End
    Exec pInsETLLog
	        @ETLAction = 'pETLFillDimDates'
	       ,@ETLLogMessage = 'DimDates filled';
    Set @ReturnCode = +1
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback Tran;
    Declare @ErrorMessage nvarchar(1000) = Error_Message();
	  Exec pInsETLLog 
	     @ETLAction = 'pETLFillDimDates'
	    ,@ETLLogMessage = @ErrorMessage;
    Set @ReturnCode = -1;
  End Catch
  Return @ReturnCode;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLFillDimDates;
 Print @Status;
 Select * From DimDates;
 Select * From vETLLog;
*/
go


/****** [dbo].[DimProducts] ******/
go 
Create or Alter View vETLDimProducts
/* Author: <YourNameHere>
** Desc: Extracts and transforms data for DimProducts
** Change Log: When,Who,What
** 2021-01-17,<YourNameHere>,Created Sproc.
*/
As
  SELECT '<Your Code Here>' as TODO
go
/* Testing Code:
 Select * From vETLDimProducts;
*/

go
Create or Alter Procedure pETLSyncDimProducts
/* Author: <YourNameHere>
** Desc: Updates data in DimProducts using the vETLDimProducts view
** Change Log: When,Who,What
** 2021-01-17,<YourNameHere>,Created Sproc.
*/
AS
 Begin
  Declare @ReturnCode int = 0;
  Begin Try
    -- ETL Processing Code --
    SELECT '<Your Code Here>' as TODO

    -- ETL Logging Code --
    Exec pInsETLLog
	        @ETLAction = 'pETLSyncDimProducts'
	       ,@ETLLogMessage = 'DimProducts synced';
    Set @ReturnCode = +1
  End Try
  Begin Catch
     Declare @ErrorMessage nvarchar(1000) = Error_Message();
	 Exec pInsETLLog 
	      @ETLAction = 'pETLSyncDimProducts'
	     ,@ETLLogMessage = @ErrorMessage;
    Set @ReturnCode = -1
  End Catch
  Return @ReturnCode;
 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLSyncDimProducts;
 Print @Status;
 Select * From DimProducts Order By ProductID
*/


/****** [dbo].[DimCustomers] ******/
go 
Create or Alter View vETLDimCustomers
/* Author: <YourNameHere>
** Desc: Extracts and transforms data for DimCustomers
** Change Log: When,Who,What
** 2021-01-17,<YourNameHere>,Created Sproc.
*/
As
  SELECT '<Your Code Here>' as TODO
go
/* Testing Code:
 Select * From vETLDimCustomers;
*/

go
Create or Alter Procedure pETLSyncDimCustomers
/* Author: <YourNameHere>
** Desc: Inserts data into DimCustomers
** Change Log: When,Who,What
** 2021-01-17,<YourNameHere>,Created Sproc.
*/
As
 Begin
  Declare @ReturnCode int = 0;
	Select '<Your Code Here>' as TODO

    -- ETL Processing Code --

    -- ETL Logging Code --

    -- Error Handling Code --

    -- ETL Logging Code --

 End
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLSyncDimCustomers;
 Print @Status;
*/
go


/****** [dbo].[FactOrders] ******/
go 
Create or Alter View vETLFactOrders
/* Author: <YourNameHere>
** Desc: Extracts and transforms data for FactOrders
** Change Log: When,Who,What
** 2021-01-17,<YourNameHere>,Created Sproc.
*/
As
  SELECT '<Your Code Here>' as TODO
go
/* Testing Code:
 Select * From vETLDimCustomers;
*/

go
Create or Alter Procedure pETLSyncFactOrders
/* Author: <YourNameHere>
** Desc: Inserts data into FactOrders
** Change Log: When,Who,What
** 2021-01-17,<YourNameHere>,Created Sproc.
*/
As
 Begin
  Declare @ReturnCode int = 0;
  Begin Try
    -- ETL Processing Code --
	Begin Tran;
		Select '<Your Code Here>' as TODO
	Commit Tran;
	Set @ReturnCode = +1
    Exec pInsETLLog
	        @ETLAction = 'pETLSyncFactOrders'
	       ,@ETLLogMessage = 'FactSales Synced';
    Set @ReturnCode = 1;
   End try
   Begin catch
	 IF @@TranCount > 0 Rollback Tran;
     Declare @ErrorMessage nvarchar(1000) = Error_Message()
	 Exec pInsETLLog 
	      @ETLAction = 'pETLSyncFactOrders'
	     ,@ETLLogMessage = @ErrorMessage;
     Set @ReturnCode = -1;
   End Catch
   Return @ReturnCode;
 End
;
go
/* Testing Code:
 Declare @Status int;
 Exec @Status = pETLSyncFactOrders;
 Print @Status;
*/
go

--********************************************************************--
-- C)  NOT NEEDED FOR INCREMENTAL LOADING: Re-Create the FOREIGN KEY CONSTRAINTS
--********************************************************************--


--********************************************************************--
-- D) Review the results of this script
--********************************************************************--
go
Declare @Status int = 0;
Exec @Status = pETLSyncDimProducts;
Select [Object] = 'pETLSyncDimProducts', [Status] = @Status;

Exec @Status = pETLSyncDimCustomers;
Select [Object] = 'pETLSyncDimCustomers', [Status] = @Status;

Exec @Status = pETLFillDimDates;
Select [Object] = 'pETLFillDimDates', [Status] = @Status;

Exec @Status = pETLSyncFactOrders;
Select [Object] = 'pETLFillFactOrders', [Status] = @Status;

go
Select * from [dbo].[DimProducts];
Select * from [dbo].[DimCustomers];
Select * from [dbo].[DimDates];
Select * from [dbo].[FactSalesOrders];