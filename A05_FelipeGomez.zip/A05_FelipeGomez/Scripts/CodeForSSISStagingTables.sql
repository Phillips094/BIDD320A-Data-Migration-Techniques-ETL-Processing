USE TempDB;
If (object_id('CustomersStaging') is not null)
Drop Table CustomersStaging;
Go
Create Table CustomersStaging
(CustomersStaging int identity Primary Key
,CustomerFirstName nvarchar(100)
,CustomerLastName nvarchar(100)
,CustomerEmail nvarchar(100)
,CustomerPhone nvarchar(100) );

Go
If (object_id('StagingInValidPhones') is not null)
Drop Table StagingInValidPhones;
Go
Create Table StagingInValidPhones
(CustomersStaging int identity Primary Key
,CustomerFirstName nvarchar(100)
,CustomerLastName nvarchar(100)
,CustomerEmail nvarchar(100)
,CustomerPhone nvarchar(100) );