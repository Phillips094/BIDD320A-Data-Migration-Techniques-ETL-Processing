# -------------------------------------------------- #
# Title: Email Validator and Processor
# Description: Writing and Reading Data from a file
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# -------------------------------------------------- #
# re is Python's regular expressions module 
import re 
  
strRegex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
strSourceDataFileName = "C:\\DataToProcess\\EmailData.txt"
strValidDataFileName = "C:\\DataToProcess\\ValidEmailData.txt"
strInvalidDataFileName = "C:\\DataToProcess\\InvalidEmailData.txt"

# Open Files for Writing
objValidDataStream = open(strValidDataFileName, 'w')
objInValidDataStream = open(strInvalidDataFileName, 'w')
objSourceDataStream = open(strSourceDataFileName, 'r')


# Read the first (header) row of data and move to the next
objSourceDataStream.readline() 

# Read the other lines of text from the source file
while True:
  strLine = objSourceDataStream.readline()
  if strLine == '': 
    break  # out of the loop
  else:
    if(re.search(strRegex,strLine)):
      print("Valid Email")  
      objValidDataStream.write(strLine)
    else:  
      print("Invalid Email")
    objInValidDataStream.write(strLine)


objSourceDataStream.close()
objValidDataStream.close()
objInValidDataStream.close()
