﻿# Create variables with the file names and paths.
$strSourceDataFileName = "C:\Data\TestData.csv"
$strValidDataFileName = "C:\Data\ValidPhoneData.txt"
$strInValidDataFileName = "C:\Data\InvalidPhoneData.txt"

# Define the regular expression
$strRegex = "\d{3}-\d{3}-\d{4}"

# Open Files for Reading
$objSourceDataStream = [System.IO.StreamReader] $strSourceDataFileName

# Open Files for Writing
$objValidDataStream = [System.IO.StreamWriter] $strValidDataFileName
$objInvalidDataStream = [System.IO.StreamWriter] $strInValidDataFileName

# Read the first (header) row of data and move to the next
$strLine = $objSourceDataStream.ReadLine()
write $strLine

# Read more lines of text from the source file
while (($strLine = $objSourceDataStream.ReadLine()) -ne $null) { 
    If ($strLine -match $strRegex)
    {
      Write "Valid Email - $strLine"
      $objValidDataStream.WriteLine($strLine) 
    }
    Else
    {
      Write "Invalid Email - $strLine"
      $objInvalidDataStream.WriteLine($strLine)
    }
}

# Close the connections to the files
$objValidDataStream.Close()
$objInvalidDataStream.Close()


