# -------------------------------------------------- #
# Title: Email Validator and Processor
# Description: Writing and Reading Data from a file
# ChangeLog (Who,When,What):
# FGomez,2.13.2024,Created started script
# -------------------------------------------------- #
# re is Python's regular expressions module 
import re 
  
strRegex = r'\d{3}-\d{3}-\d{4}'
strSourceDataFileName = "C:\\Data\\TestData.csv"
strValidDataFileName = "C:\\Data\\ValidPhoneData.txt"
strInvalidDataFileName = "C:\\Data\\InvalidPhoneData.txt"

# Open Files for Writing
objValidDataStream = open(strValidDataFileName, 'w')
objInValidDataStream = open(strInvalidDataFileName, 'w')
objSourceDataStream = open(strSourceDataFileName, 'r')


# Read the first (header) row of data and move to the next
objSourceDataStream.readline()

# Read the other lines of text from the source file
while True:
  strLine = objSourceDataStream.readline() 
  if strLine == '': 
    break  # out of the loop
  else:
    if(re.search(strRegex,strLine)):
      print("Valid Phone")  
      objValidDataStream.write(strLine)
    else:  
      print("Invalid Phone")
      objInValidDataStream.write(strLine)


objSourceDataStream.close()
objValidDataStream.close()
objInValidDataStream.close()
