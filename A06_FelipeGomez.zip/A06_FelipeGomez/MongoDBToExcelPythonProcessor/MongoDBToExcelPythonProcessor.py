print("Test")
import pymongo
import pprint
import openpyxl
import json
import csv
import datetime


# Step 1a: Connect to MongoDB
strCon = 'mongodb+srv://BICert:BICertPa$$w0rd@cluster0.7zqwqag.mongodb.net/?retryWrites=true&w=majority'
objCon = pymongo.MongoClient(strCon)
pprint.pprint(objCon.server_info())

db = objCon["A06NonSQLETL"] # database
objCol = db['InventoryData'] # collection


# Step 1b: Extract Data
curData = objCol.find() # Find All
curData.sort([("InventoryDate",pymongo.ASCENDING),("ProductName",pymongo.ASCENDING), ("CategoryID", pymongo.ASCENDING)])

strData = "InventoryID_CategoryID_ProductID,InventoryDate,CategoryName,ProductName,UnitPrice,Count,Employee,Manager\n"
for val in curData:
 strData += ( val["InventoryID"] + '_' + val["CategoryID"] + '_' + val["ProductID"] # Step 2a: Transform Data
 + ',' + val["InventoryDate"]
 + ',' + val["CategoryName"]
 + ',' + val["ProductName"]
 + ',' + val["UnitPrice"]
 + ',' + val["Count"]
 + ',' + val["Employee"]
 + ',' + val["Manager"]
 + '\n'
 ) # Data should now look like this" '6_17,1/1/2017,Meat/Poultry,Alice Mutton,39,0,Steven Buchanan,Andrew Fuller'
print('Writing the following to a csv file:\n'+ strData.replace("'s","s")) 

# Step 3: Load Data
file_object = open("../data/InventoryData1.csv", 'w')
file_object.write(strData.replace("'s","s"))
file_object.close()
