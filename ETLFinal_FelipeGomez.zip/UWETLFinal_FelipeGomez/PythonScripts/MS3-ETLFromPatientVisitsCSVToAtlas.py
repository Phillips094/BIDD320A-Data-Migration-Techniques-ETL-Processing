# -*- coding: utf-8 -*-
# ^^^^^^^^^^^^^^^^^^^^
# The above is a "Magic Comment" for working with Unicode data
# https://www.python.org/dev/peps/pep-0263/
# https://towardsdatascience.com/a-guide-to-unicode-utf-8-and-strings-in-python-757a232db95c

'''*************************************************************************--
-- Desc: This script moves data from a CSV file to MongoDB Atlas cloud
-- Change Log: When,Who,What
-- 2024-03-15,FGomez,Created File

# IMPORTANT:
1. Works best if you create the Database and Collection manually on Atlas before running this code!
2. Make sure you allow you computer's ip address on the Network Access page,
   then create a User called BICert with read and write permission the Database Access page, noting its password.
   Finally, get a connection string to replace the one used here using the Connect Button!
# mongodb+srv://BICert:<password>@cluster0.omzbi.azure.mongodb.net/myFirstDatabase?retryWrites=true&w=majority
--**************************************************************************'''
import pymongo
import csv
import datetime as dt
print('Start PatientVisits Import:', dt.datetime.now())  # Takes about 2 minutes to run!

strFilePath = "../DataFiles/PatientVisits.csv"
#strCon = "mongodb+srv://BICert:Pa$$w0rd@cluster0-omzbi.azure.mongodb.net/FinalDB?retryWrites=true&w=majority"
#strCon = 'mongodb+srv://BICert:BICert@cluster0.oqby8px.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
strCon = 'mongodb+srv://BICert:BICert@cluster0.oqby8px.mongodb.net/ClinicReportsData?retryWrites=true&w=majority&appName=Cluster0'

objCon = pymongo.MongoClient(strCon)
objDB = objCon["ClinicReportsData"]  # Creates or Connects a database
objCol = objDB['PatientVisits']  # Will reference a collection object
boolResetDB = True # Change to False to append
intLastID = 0

if boolResetDB: 
    if objDB["PatientVisits"].drop():
        print('collection dropped')  # Without this you get duplicates when ran twice
    objCol = objDB['PatientVisits']  # recreates a new collection if it does not exist
else:
    # Selecting the last _id in the document
    curLastRow = objCol.find().sort([("_id", -1)]).limit(1)  # -1 get last and +1 gets first
    for row in curLastRow:
        intLastID = row["_id"]
    print("Last ID Was >>> ", intLastID)

# Import with Insert (and a new _id added!)
try:
    fPatientVisits = open(strFilePath, 'r', encoding='utf-8-sig')
    rPatientVisits = csv.DictReader(fPatientVisits)
    for row in rPatientVisits:
        intLastID += 1
        row["_id"] = intLastID
        objCol.insert_one(row)
except Exception as e:
    print('LineID', intLastID, e)  # Adding the line number help with troubleshooting
print('Done with PatientVisits Import:', (dt.datetime.now()))

objCon.close()
