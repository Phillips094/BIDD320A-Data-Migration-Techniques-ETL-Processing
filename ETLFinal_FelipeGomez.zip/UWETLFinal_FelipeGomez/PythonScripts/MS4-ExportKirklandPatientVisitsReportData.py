# -*- coding: utf-8 -*-
'''*************************************************************************--
-- Desc: This script moves data from MongoDB Atlas cloud to a 
-- CSV file for creating reports
-- Change Log: When,Who,What
-- 2024-03-15,FGomez,Created File
--**************************************************************************'''
import pymongo

strCon = 'mongodb+srv://BICert:BICert@cluster0.oqby8px.mongodb.net/ClinicReportsData?retryWrites=true&w=majority&appName=Cluster0'

objCon = pymongo.MongoClient(strCon)
db = objCon["ClinicReportsData"]  # database
objCol = db['PatientVisits']  # collection

# Verify Data Was Uploaded
curData = objCol.find({"ClinicName": "Kirkland"})

objF = open('..\DataFiles\KirklandPatientVisitsReportData.csv', 'w')
tplCol = ("VisitDate","PatientFullName","PatientCity","DoctorFullName","ProcedureName","ProcedureVisitCharge")
objF.write("%s,%s,%s,%s,%s,%s\n" % tplCol)
for val in curData:
    objF.write("%s,%s,%s,%s,%s,%d\n" % (val["VisitDate"],
                                        val["PatientFullName"],
                                        val["PatientCity"],
                                        val["DoctorFullName"],
                                        val["ProcedureName"],
                                        float(val["ProcedureVisitCharge"])))
objF.close()


