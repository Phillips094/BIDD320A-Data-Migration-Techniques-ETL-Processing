/************************************************************************************************
Desc: This file creates several report views.
Dev: FGomez
Date: 03/11/2024
Change Log: (When, Who, What)
-- 2024-03-07,FGomez,Created File
************************************************************************************************/
Use [DWClinicReportData];
go

-- Since MongoDB as issues with some characters such as commas, we need to replace them
Declare @TestData varchar(1000) = '    This,is/A\test,for cleaning Mongo''s data    '
Select 
 [Original] = @TestData
,[No Single Quotes] = replace(@TestData, '''', '')
,[No Commas] = replace(@TestData, ',', ' ')
,[No Forward Slashes] = replace(@TestData, '/', '|')
,[No Back Slashes] = replace(@TestData, '\', '|')
,[No Extra Spaces] = rtrim(ltrim(@TestData))
go

If (Object_ID('fReplaceMongoDBProblemCharacters') is not null) Drop Function fReplaceMongoDBProblemCharacters;
go
Create Function dbo.fReplaceMongoDBProblemCharacters(@Data varchar(1000))
Returns varchar(1000)
As
Begin
 Select @Data = replace(@Data, '''','');
 Select @Data = replace(@Data, ',',' ');
 Select @Data = replace(@Data, '/',' | ');
 Select @Data = replace(@Data, '\',' | ');
 Select @Data = rtrim(ltrim(@Data));
 Return @Data;
End;
go
Declare @TestData varchar(1000) =  '    This,is/A\test,for cleaning Mongo''s data    ';
Select dbo.fReplaceMongoDBProblemCharacters(@TestData);
go

If (Object_ID('vRptDoctorShifts') is not null) Drop View vRptDoctorShifts;
go
Create View vRptDoctorShifts
As
Select Top 1000
 [ShiftDate] = Cast(Cast([FullDate] as date) as varchar(100))
,[ClinicName] = dc.[ClinicName]
,[ClinicCity] = dc.[ClinicCity]
,[ClinicState] = dc.[ClinicState]
,[ShiftID] = ds.[ShiftID]
,[ShiftStart] = ds.[ShiftStart]
,[ShiftEnd] = ds.[ShiftEnd]
,[DoctorFullName] = ddc.[DoctorFullName]
,[HoursWorked] = fds.[HoursWorked]
From [dbo].[FactDoctorShifts] as fds
Join [dbo].[DimDates] as dd
 On fds.[ShiftDateKey] = dd.[DateKey]
Join [dbo].[DimClinics] dc
 On fds.[ClinicKey] = dc.[ClinicKey]
Join [dbo].[DimShifts] ds
 On fds.[ShiftKey] = ds.[ShiftKey]
Join [dbo].[DimDoctors] ddc
 On fds.[DoctorKey] = ddc.[DoctorKey]
Order By [ShiftDate];
go

If (Object_ID('vRptPatientVisits') is not null) Drop View vRptPatientVisits;
go
Create View vRptPatientVisits
As
Select Top 1000
 [VisitDate] = Cast(Cast([FullDate] as date) as varchar(100))
,[ClinicName] = dc.[ClinicName]
,[ClinicCity] = dc.[ClinicCity]
,[ClinicState] = dc.[ClinicState]
,[PatientFullName] = dp.[PatientFullName]
,[PatientCity] = dp.[PatientCity]
,[PatientState] = dp.[PatientState]
,[DoctorFullName] = ddc.[DoctorFullName]
,[ProcedureName] = dbo.fReplaceMongoDBProblemCharacters(dpr.[ProcedureName]) 
,[ProcedureVisitCharge] = fv.[ProcedureVistCharge]
From [dbo].[FactVisits] as fv
Join [dbo].[DimDates] as dd
 On fv.[DateKey] = dd.[DateKey]
Join [dbo].[DimClinics] dc
 On fv.[ClinicKey] = dc.[ClinicKey]
Join [dbo].[DimPatients] as dp
 On fv.[PatientKey] = dp.[PatientKey]
Join [dbo].[DimDoctors] ddc
 On fv.[DoctorKey] = ddc.[DoctorKey]
Join [dbo].[DimProcedures] as dpr
 On fv.[ProcedureKey] = dpr.[ProcedureKey]
Where dp.[IsCurrent] = 1
Order By [VisitDate];
go
