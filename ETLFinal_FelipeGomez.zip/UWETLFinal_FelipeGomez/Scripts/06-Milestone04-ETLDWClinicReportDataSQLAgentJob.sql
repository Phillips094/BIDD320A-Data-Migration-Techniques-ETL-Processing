-- Create Scheduled Daily Job for SSIS Package using SQL Server Agent --
------------------------------------------------------

DECLARE @jobID1 Binary(16)
SELECT @jobID1 = job_id FROM msdb.dbo.sysjobs WHERE name = N'ETLDWClinicReportData'
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'ETLDWClinicReportData') EXEC msdb.dbo.sp_delete_job @jobID1


USE [DWClinicReportData]
GO
CREATE OR ALTER PROC pETLDWJob AS
/**********************************************************************************
Desc: Schedules Daily ETL Job run to import NewPatients and Visits CSV files data into Patients Database
Dev: FGomez
Date: 03/11/2024
Change Log: (When, Who, What)
	Felipe Gomez, 03/11/2024, Developed to create a scheduled job run for our ETL process for performing Incremental Loading for our Dimension and Fact tables for our DWClinicReportData Data Warehouse.
************************************************************************************/
Begin
/****** Object:  Job [ETLFinalDWETLCodeRun]    Script Date: 3/10/2024 7:13:45 PM ******/
--IF EXISTS (SELECT * FROM msdb.dbo.sysjobs WHERE name = N'ETLFinalDWETLCodeRun') EXEC msdb.dbo.sp_delete_job N'9CE4A817-0D8D-4337-8377-AC636AC12B0A'
IF NOT EXISTS (SELECT * FROM msdb.dbo.sysjobs WHERE name = N'ETLDWClinicReportData')
/****** Object:  Job [ETLDWClinicReportData]    Script Date: 3/15/2024 11:45:29 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 3/15/2024 11:45:29 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ETLDWClinicReportData', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Daily ETLFinal SSIS Package DW ETL Code Run', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Daily DW ETL Code Schedule Run]    Script Date: 3/15/2024 11:45:29 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Daily DW ETL Code Schedule Run', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/FILE "\"C:\_BISolutions\UWETLFinal_FelipeGomez\ETLFinalSSISPackages\DWClinicReportDataETL.dtsx\"" /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Daily DW ETL Mongo DB Run]    Script Date: 3/15/2024 11:45:29 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Daily DW ETL Mongo DB Run', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/FILE "\"C:\_BISolutions\UWETLFinal_FelipeGomez\ETLFinalSSISPackages\ETLClinicReportsDocumentData.dtsx\"" /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Daily DW ETL Report Data Run]    Script Date: 3/15/2024 11:45:29 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Daily DW ETL Report Data Run', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/FILE "\"C:\_BISolutions\UWETLFinal_FelipeGomez\ETLFinalSSISPackages\ExportReportData.dtsx\"" /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily ETLFinal SSIS DW ETL Code Run', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20240315, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'4b189131-dbdf-4ed0-aa3f-311fce8381f1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
END
GO

Exec pETLDWJob;
go